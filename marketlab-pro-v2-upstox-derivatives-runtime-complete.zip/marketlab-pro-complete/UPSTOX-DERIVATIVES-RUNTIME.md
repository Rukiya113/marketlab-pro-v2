# Upstox Derivatives Runtime

This build replaces the placeholder derivative universe with a real Upstox-backed index derivative registry.

- Loads the official NSE BOD JSON instrument master and caches it in-process for six hours.
- Maps contracts by Upstox `underlying_key` and preserves `instrument_key` as the canonical broker contract key.
- Exposes non-expired index futures and CE/PE options with real expiry, strike, lot size and trading symbol.
- When an authenticated Upstox session exists, enriches option expiries through `/v2/option/chain` with LTP, bid, ask, volume, OI and Greeks.
- Enriches current futures through `/v2/market-quote/quotes`.
- Keeps prices/Greeks null when Upstox is disconnected rather than fabricating market state.
- Adds FINNIFTY and MIDCPNIFTY to the core index identities.
- Keeps Settings non-blocking by rendering safe defaults before API hydration.

AUTO LIVE remains locked. This runtime is intended to feed Options Intelligence and AUTO PAPER validation first.
