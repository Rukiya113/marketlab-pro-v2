import { NextRequest, NextResponse } from 'next/server';
import type { CanonicalInstrumentId } from '@/lib/market/events';
import { buildUpstoxDerivativeUniverse } from '@/lib/derivatives/upstox';
import { setDerivativeUniverse } from '@/lib/derivatives/store';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const id = (request.nextUrl.searchParams.get('instrument') ?? 'IN:NSE:INDEX:NIFTY50') as CanonicalInstrumentId;
  const universe = await buildUpstoxDerivativeUniverse(id);
  setDerivativeUniverse(universe);
  return NextResponse.json(universe, { headers: { 'Cache-Control': 'no-store' } });
}
