import type { CanonicalInstrumentId } from '@/lib/market/events';
import { CORE_INSTRUMENTS } from '@/lib/market/instruments';
import { getToken } from '@/lib/upstox/session';
import type { DerivativeContract, DerivativeUniverse, OptionSide } from './types';

const NSE_MASTER_URL = 'https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz';
const MASTER_TTL_MS = 6 * 60 * 60 * 1000;

type UpstoxInstrument = {
  segment?: string;
  exchange?: string;
  expiry?: number | string;
  instrument_type?: string;
  instrument_key?: string;
  lot_size?: number;
  underlying_key?: string;
  underlying_symbol?: string;
  trading_symbol?: string;
  strike_price?: number;
};

type OptionLeg = {
  instrument_key?: string;
  market_data?: { ltp?: number; volume?: number; oi?: number; bid_price?: number; ask_price?: number };
  option_greeks?: { iv?: number; delta?: number; gamma?: number; theta?: number; vega?: number };
};

type OptionChainRow = {
  expiry?: string;
  strike_price?: number;
  call_options?: OptionLeg;
  put_options?: OptionLeg;
};

let masterCache: { at: number; rows: UpstoxInstrument[] } | null = null;

function core(id: CanonicalInstrumentId) {
  return CORE_INSTRUMENTS.find((item) => item.id === id) ?? null;
}

function expiryDate(value: number | string | undefined): string | null {
  if (value == null) return null;
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return new Date(n).toISOString().slice(0, 10);
}

function n(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

async function loadNseMaster(): Promise<UpstoxInstrument[]> {
  if (masterCache && Date.now() - masterCache.at < MASTER_TTL_MS) return masterCache.rows;
  const response = await fetch(NSE_MASTER_URL, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Upstox NSE instrument master returned ${response.status}`);
  const rows = await response.json() as UpstoxInstrument[];
  masterCache = { at: Date.now(), rows };
  return rows;
}

function empty(id: CanonicalInstrumentId): DerivativeUniverse {
  return { underlyingId: id, state: 'OFFLINE', contracts: [], updatedAt: Date.now() };
}

function fromMaster(id: CanonicalInstrumentId, rows: UpstoxInstrument[]): DerivativeContract[] {
  const identity = core(id);
  if (!identity) return [];
  const now = new Date().toISOString().slice(0, 10);
  return rows
    .filter((row) => row.segment === 'NSE_FO' && row.underlying_key === identity.upstoxKey)
    .map((row): DerivativeContract | null => {
      const expiry = expiryDate(row.expiry);
      const type = row.instrument_type;
      if (!expiry || expiry < now || !row.instrument_key || !row.trading_symbol || !row.lot_size) return null;
      if (type !== 'FUT' && type !== 'CE' && type !== 'PE') return null;
      return {
        instrumentKey: row.instrument_key,
        underlyingId: id,
        symbol: row.trading_symbol,
        segment: type === 'FUT' ? 'FUTURES' : 'OPTIONS',
        expiry,
        strike: type === 'FUT' ? null : n(row.strike_price),
        optionSide: type === 'FUT' ? null : type as OptionSide,
        lotSize: row.lot_size,
        bid: null, ask: null, last: null, oi: null, volume: null,
        iv: null, delta: null, gamma: null, theta: null, vega: null, at: null,
      };
    })
    .filter((row): row is DerivativeContract => row !== null)
    .sort((a, b) => a.expiry.localeCompare(b.expiry) || (a.strike ?? 0) - (b.strike ?? 0) || (a.optionSide ?? '').localeCompare(b.optionSide ?? ''));
}

async function optionChain(identityKey: string, expiry: string, token: string): Promise<OptionChainRow[]> {
  const url = new URL('https://api.upstox.com/v2/option/chain');
  url.searchParams.set('instrument_key', identityKey);
  url.searchParams.set('expiry_date', expiry);
  const response = await fetch(url, { headers: { Accept: 'application/json', Authorization: `Bearer ${token}` }, cache: 'no-store' });
  if (!response.ok) return [];
  const payload = await response.json() as { data?: OptionChainRow[] };
  return Array.isArray(payload.data) ? payload.data : [];
}

function enrichOptions(contracts: DerivativeContract[], rows: OptionChainRow[]): void {
  const byKey = new Map(contracts.map((contract) => [contract.instrumentKey, contract]));
  for (const row of rows) {
    for (const leg of [row.call_options, row.put_options]) {
      if (!leg?.instrument_key) continue;
      const contract = byKey.get(leg.instrument_key);
      if (!contract) continue;
      const market = leg.market_data;
      const greeks = leg.option_greeks;
      contract.last = n(market?.ltp); contract.bid = n(market?.bid_price); contract.ask = n(market?.ask_price);
      contract.volume = n(market?.volume); contract.oi = n(market?.oi);
      contract.iv = n(greeks?.iv); contract.delta = n(greeks?.delta); contract.gamma = n(greeks?.gamma);
      contract.theta = n(greeks?.theta); contract.vega = n(greeks?.vega); contract.at = Date.now();
    }
  }
}

async function enrichFutures(contracts: DerivativeContract[], token: string): Promise<void> {
  const futures = contracts.filter((contract) => contract.segment === 'FUTURES').slice(0, 12);
  if (!futures.length) return;
  const url = new URL('https://api.upstox.com/v2/market-quote/quotes');
  url.searchParams.set('instrument_key', futures.map((contract) => contract.instrumentKey).join(','));
  const response = await fetch(url, { headers: { Accept: 'application/json', Authorization: `Bearer ${token}` }, cache: 'no-store' });
  if (!response.ok) return;
  const payload = await response.json() as { data?: Record<string, Record<string, unknown>> };
  const data = payload.data ?? {};
  for (const contract of futures) {
    const quote = data[contract.instrumentKey] ?? Object.values(data).find((item) => item.instrument_token === contract.instrumentKey);
    if (!quote) continue;
    contract.last = n(quote.last_price);
    contract.volume = n(quote.volume);
    contract.oi = n(quote.oi);
    const depth = quote.depth as { buy?: Array<{price?:number}>; sell?: Array<{price?:number}> } | undefined;
    contract.bid = n(depth?.buy?.[0]?.price); contract.ask = n(depth?.sell?.[0]?.price); contract.at = Date.now();
  }
}

export async function buildUpstoxDerivativeUniverse(id: CanonicalInstrumentId): Promise<DerivativeUniverse> {
  const identity = core(id);
  if (!identity || identity.exchange !== 'NSE' || identity.type !== 'INDEX') return empty(id);
  try {
    const master = await loadNseMaster();
    const contracts = fromMaster(id, master);
    if (!contracts.length) return empty(id);
    const token = await getToken();
    if (token) {
      const optionExpiries = [...new Set(contracts.filter((c) => c.segment === 'OPTIONS').map((c) => c.expiry))].slice(0, 4);
      const chains = await Promise.all(optionExpiries.map((expiry) => optionChain(identity.upstoxKey, expiry, token)));
      for (const rows of chains) enrichOptions(contracts, rows);
      await enrichFutures(contracts, token);
    }
    return { underlyingId: id, state: token ? 'LIVE' : 'OFFLINE', contracts, updatedAt: Date.now() };
  } catch (error) {
    console.error('[MarketLab derivatives]', error);
    return empty(id);
  }
}
