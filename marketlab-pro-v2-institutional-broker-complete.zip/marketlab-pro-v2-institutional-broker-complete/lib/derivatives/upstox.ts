import type {CanonicalInstrumentId} from '@/lib/market/events';
import {CORE_INSTRUMENTS} from '@/lib/market/instruments';
import {setOptionChain} from '@/lib/options/store';
import type {OptionChainSnapshot,OptionContract} from '@/lib/options/types';
import {upstoxGet} from '@/lib/upstox/http';
import type {DerivativeContract,DerivativeUniverse,OptionSide} from './types';
import {setDerivativeUniverse} from './store';

type ApiEnvelope<T>={status?:string;data?:T};
type RawContract={instrument_key?:string;trading_symbol?:string;expiry?:string|number;strike_price?:number;lot_size?:number;tick_size?:number;instrument_type?:string;underlying_key?:string;underlying_symbol?:string};
type RawChainRow={expiry?:string;strike_price?:number;underlying_spot_price?:number;call_options?:RawOptionLeg;put_options?:RawOptionLeg};
type RawOptionLeg={instrument_key?:string;market_data?:Record<string,unknown>;option_greeks?:Record<string,unknown>};
type SearchData={data?:RawContract[]}|RawContract[];
type QuoteEnvelope=ApiEnvelope<Record<string,Record<string,unknown>>>;

const CACHE_MS=30_000;
const cache=new Map<CanonicalInstrumentId,{at:number;value:DerivativeUniverse}>();

function identity(id:CanonicalInstrumentId){return CORE_INSTRUMENTS.find(x=>x.id===id)??null}
function n(v:unknown):number|null{return typeof v==='number'&&Number.isFinite(v)?v:null}
function s(v:unknown):string{return typeof v==='string'?v:''}
function expiry(v:string|number|undefined):string{
 if(typeof v==='string') return v.slice(0,10);
 if(typeof v==='number') return new Date(v).toISOString().slice(0,10);
 return '';
}
function marketValue(m:Record<string,unknown>|undefined,...keys:string[]):number|null{if(!m)return null;for(const k of keys){const x=n(m[k]);if(x!==null)return x}return null}
function quoteValue(q:Record<string,unknown>|undefined,...keys:string[]):number|null{return marketValue(q,...keys)}
function firstDepth(q:Record<string,unknown>|undefined,side:'buy'|'sell'):number|null{
 const depth=q?.depth as {buy?:Array<Record<string,unknown>>;sell?:Array<Record<string,unknown>>}|undefined;
 return marketValue(depth?.[side]?.[0], 'price');
}

async function optionContracts(upstoxKey:string):Promise<RawContract[]>{
 const response=await upstoxGet<ApiEnvelope<RawContract[]>>('/option/contract',{instrument_key:upstoxKey});
 return Array.isArray(response.data)?response.data:[];
}
async function optionChain(upstoxKey:string,expiryDate:string):Promise<RawChainRow[]>{
 const response=await upstoxGet<ApiEnvelope<RawChainRow[]>>('/option/chain',{instrument_key:upstoxKey,expiry_date:expiryDate});
 return Array.isArray(response.data)?response.data:[];
}
async function futures(upstoxKey:string,label:string):Promise<RawContract[]>{
 const query=label==='NIFTY 50'?'NIFTY':label;
 const response=await upstoxGet<ApiEnvelope<SearchData>>('/instruments/search',{query,exchanges:'NSE',segments:'FUT',page_number:1,records:30});
 const data=response.data;
 const rows=Array.isArray(data)?data:Array.isArray(data?.data)?data.data:[];
 return rows.filter(x=>x.underlying_key===upstoxKey||s(x.underlying_symbol).toUpperCase().replace(/\s+/g,'').includes(query.toUpperCase().replace(/\s+/g,'')));
}
async function quotes(keys:string[]):Promise<Record<string,Record<string,unknown>>>{
 if(!keys.length)return {};
 const out:Record<string,Record<string,unknown>>={};
 for(let i=0;i<keys.length;i+=500){
   const response=await upstoxGet<QuoteEnvelope>('/market-quote/quotes',{instrument_key:keys.slice(i,i+500).join(',')});
   Object.assign(out,response.data??{});
 }
 return out;
}

export async function loadDerivativeUniverse(id:CanonicalInstrumentId,force=false):Promise<DerivativeUniverse>{
 const prior=cache.get(id);if(!force&&prior&&Date.now()-prior.at<CACHE_MS)return prior.value;
 const base=identity(id);if(!base) return {underlyingId:id,state:'OFFLINE',contracts:[],updatedAt:Date.now()};
 const contracts=await optionContracts(base.upstoxKey);
 const expiries=[...new Set(contracts.map(x=>expiry(x.expiry)).filter(Boolean))].sort();
 const nearest=expiries[0]??'';
 const chainRows=nearest?await optionChain(base.upstoxKey,nearest):[];
 const optionMeta=new Map(contracts.map(x=>[x.instrument_key??'',x]));
 const derivatives:DerivativeContract[]=[];const options:OptionContract[]=[];
 let spot:number|null=null;
 for(const row of chainRows){
   spot=spot??n(row.underlying_spot_price);
   for(const [side,leg] of [['CE',row.call_options],['PE',row.put_options]] as const){
     if(!leg?.instrument_key)continue;
     const meta=optionMeta.get(leg.instrument_key);const m=leg.market_data??{};const g=leg.option_greeks??{};
     const strike=n(row.strike_price)??n(meta?.strike_price)??0;const exp=expiry(meta?.expiry)||nearest;const lot=n(meta?.lot_size)??1;
     const bid=marketValue(m,'bid_price','bidPrice');const ask=marketValue(m,'ask_price','askPrice');const last=marketValue(m,'ltp','last_price','lastPrice');
     const oi=marketValue(m,'oi','open_interest');const volume=marketValue(m,'volume','volume_traded_today');const at=Date.now();
     const dc:DerivativeContract={instrumentKey:leg.instrument_key,underlyingId:id,symbol:meta?.trading_symbol??leg.instrument_key,segment:'OPTIONS',expiry:exp,strike,optionSide:side as OptionSide,lotSize:lot,bid,ask,last,oi,volume,iv:marketValue(g,'iv'),delta:marketValue(g,'delta'),gamma:marketValue(g,'gamma'),theta:marketValue(g,'theta'),vega:marketValue(g,'vega'),at};
     derivatives.push(dc);
     options.push({instrumentKey:dc.instrumentKey,tradingSymbol:dc.symbol,underlyingId:id,expiry:dc.expiry,strike,side:side as OptionSide,lotSize:lot,tickSize:n(meta?.tick_size)??0.05,bid,ask,ltp:last,volume,openInterest:oi,previousOpenInterest:marketValue(m,'prev_oi','previous_oi'),greeks:{delta:dc.delta,gamma:dc.gamma,theta:dc.theta,vega:dc.vega,iv:dc.iv},exchangeTimestamp:at});
   }
 }
 const fut=await futures(base.upstoxKey,base.displayName).catch(()=>[]);
 const futQuotes=await quotes(fut.map(x=>x.instrument_key??'').filter(Boolean)).catch(()=>({}));
 for(const meta of fut){if(!meta.instrument_key)continue;const q=futQuotes[meta.instrument_key]??Object.values(futQuotes).find(x=>s(x.instrument_token)===meta.instrument_key);derivatives.push({instrumentKey:meta.instrument_key,underlyingId:id,symbol:meta.trading_symbol??meta.instrument_key,segment:'FUTURES',expiry:expiry(meta.expiry),strike:null,optionSide:null,lotSize:n(meta.lot_size)??1,bid:firstDepth(q,'buy')??quoteValue(q,'bid_price'),ask:firstDepth(q,'sell')??quoteValue(q,'ask_price'),last:quoteValue(q,'last_price','ltp'),oi:quoteValue(q,'oi'),volume:quoteValue(q,'volume'),iv:null,delta:null,gamma:null,theta:null,vega:null,at:Date.now()});}
 const universe:DerivativeUniverse={underlyingId:id,state:derivatives.length?'LIVE':'OFFLINE',contracts:derivatives,updatedAt:Date.now()};
 const snapshot:OptionChainSnapshot={underlyingId:id,underlyingPrice:spot,expiry:nearest||null,receivedAt:Date.now(),state:options.length?'LIVE':'OFFLINE',contracts:options};
 setDerivativeUniverse(universe);setOptionChain(snapshot);cache.set(id,{at:Date.now(),value:universe});return universe;
}
