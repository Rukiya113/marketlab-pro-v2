import { PaperBroker } from './broker';

declare global {
  var __marketLabPaperBroker: PaperBroker | undefined;
}

export const paperBroker =
  globalThis.__marketLabPaperBroker ??
  (globalThis.__marketLabPaperBroker = new PaperBroker());
