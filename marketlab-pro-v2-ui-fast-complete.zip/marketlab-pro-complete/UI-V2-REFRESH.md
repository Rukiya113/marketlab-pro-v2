# MarketLab Pro V2 UI Refresh

- Pro Dark is the new default theme for fresh sessions.
- Existing saved theme preference is respected.
- Dense professional trading layout with higher contrast and clearer active states.
- Near-zero CSS transition/animation durations for immediate UI response.
- Sticky header and market strip.
- Compact Explorer, chart, X-RAY and ASURA surfaces.
- No application features removed.

Note: first navigation to a route in `next dev` can still compile that route on demand. Production builds do not have that development compilation delay.
